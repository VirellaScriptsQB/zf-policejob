-- server/main.lua (UPDATED PROPERLY - matches your simplified client)
-- ✅ NO fines
-- ✅ NO garage / vehicle spawn
-- ✅ Armory = ox_inventory SHOP (OPENED ON CLIENT = reliable)
-- ✅ Evidence = MULTIPLE stashes (Config.EvidenceStashes) (OPENED ON CLIENT = reliable)
-- ✅ Discord logs (simple webhook)
-- ✅ Duty toggle + boss announcement
-- ✅ Cuff/Escort/PutInVeh/TakeOut/Search events still exist (no item giving)

local cuffed = {}     -- [src] = true/false
local escorted = {}   -- [targetSrc] = escorterSrc

-- ========= Helpers =========

local function getPlayer(src)
    local ok, p = pcall(function()
        return exports.qbx_core:GetPlayer(src)
    end)
    return ok and p or nil
end

local function isPolice(src)
    local Player = getPlayer(src)
    return Player and Player.PlayerData and Player.PlayerData.job and Player.PlayerData.job.name == Config.PoliceJobName
end

local function isBoss(src)
    local Player = getPlayer(src)
    if not (Player and Player.PlayerData and Player.PlayerData.job) then return false end
    if Player.PlayerData.job.name ~= Config.PoliceJobName then return false end
    local grade = Player.PlayerData.job.grade
    local lvl = (type(grade) == 'table' and (grade.level or grade.grade)) or grade or 0
    return tonumber(lvl) >= (Config.RequiredBossGrade or 0)
end

local function notify(src, nType, title, msg)
    if Config.Notify and Config.Notify.Mode == 'event' then
        TriggerClientEvent(Config.Notify.EventName, src, { type = nType or 'info', title = title or 'Police', text = msg or '' })
    else
        TriggerClientEvent('ox_lib:notify', src, { type = nType or 'info', title = title or 'Police', description = msg or '' })
    end
end

local function distOk(src, target, maxDist)
    local sp = GetPlayerPed(src)
    local tp = GetPlayerPed(target)
    if sp == 0 or tp == 0 then return false end
    local d = #(GetEntityCoords(sp) - GetEntityCoords(tp))
    return d <= (maxDist or 3.0)
end

-- ========= Discord Logs =========

local function discordLog(title, message)
    if not (Config.DiscordLogs and Config.DiscordLogs.Enabled and Config.DiscordLogs.Webhook and Config.DiscordLogs.Webhook ~= '') then
        return
    end

    local payload = {
        username = (Config.DiscordLogs.Username or 'zf-policejob'),
        avatar_url = (Config.DiscordLogs.AvatarURL or nil),
        embeds = {{
            title = title or (Config.DiscordLogs.TitlePrefix or 'ZF Police Job'),
            description = message or '',
            color = (Config.DiscordLogs.EmbedColor or 5793266),
            footer = { text = os.date('%Y-%m-%d %H:%M:%S') }
        }}
    }

    PerformHttpRequest(Config.DiscordLogs.Webhook, function() end, 'POST', json.encode(payload), {
        ['Content-Type'] = 'application/json'
    })
end

local function findEvidenceConfig(stashKey)
    stashKey = tostring(stashKey or '')
    if stashKey == '' then return nil end

    for _, s in ipairs(Config.EvidenceStashes or {}) do
        if tostring(s.id) == stashKey then
            return s
        end
    end
    return nil
end

-- ========= ox_inventory: Register evidence stashes on start =========

CreateThread(function()
    Wait(500)

    if not exports.ox_inventory then
        print('[zf-policejob] ox_inventory not found. Evidence + armory shop will not work.')
        return
    end

    -- Register evidence stashes once (safe)
    for _, stash in ipairs(Config.EvidenceStashes or {}) do
        local stashId = (Config.EvidenceStashPrefix or 'zf_evidence_') .. tostring(stash.id)

        pcall(function()
            exports.ox_inventory:RegisterStash(
                stashId,
                stash.label or ('Evidence (%s)'):format(stash.id),
                stash.slots or 120,
                stash.maxWeight or 250000,
                false,
                { [Config.PoliceJobName] = 0 } -- police-only shared stash
            )
        end)
    end

    -- NOTE ABOUT ARMORY SHOP:
    -- Many ox_inventory versions do NOT support RegisterShop as an export.
    -- So we DO NOT rely on it here.
    -- You must define the shop in ox_inventory/data/shops.lua with id = Config.Armory.ShopId
end)

-- ========= Duty =========

RegisterNetEvent('zf-policejob:server:toggleDuty', function()
    local src = source
    if not isPolice(src) then
        notify(src, 'error', 'Police', 'You are not police.')
        return
    end

    local Player = getPlayer(src)
    if not Player then return end

    local current = Player.PlayerData.job and Player.PlayerData.job.onduty or false
    local newDuty = not current

    if Player.Functions and Player.Functions.SetDuty then
        local ok = pcall(function()
            Player.Functions.SetDuty(newDuty)
        end)

        if ok then
            notify(src, 'success', 'Duty', newDuty and 'You are now ON duty.' or 'You are now OFF duty.')
            if Config.DiscordLogs and Config.DiscordLogs.LogDuty ~= false then
                discordLog('Duty Toggle', ('**%s** (%d) set duty: **%s**'):format(GetPlayerName(src) or 'Unknown', src, newDuty and 'ON' or 'OFF'))
            end
        else
            notify(src, 'error', 'Duty', 'Duty toggle failed (adjust SetDuty for your QBX build).')
        end
    else
        notify(src, 'error', 'Duty', 'SetDuty not found on this QBX build.')
    end
end)

-- ========= Armory (SHOP) =========
-- OPEN ON CLIENT (reliable)
RegisterNetEvent('zf-policejob:server:openArmoryShop', function()
    local src = source
    if not isPolice(src) then return end

    if not exports.ox_inventory then
        notify(src, 'error', 'Armory', 'ox_inventory is required for the armory shop.')
        return
    end

    local shopId = Config.Armory and Config.Armory.ShopId
    if not shopId or shopId == '' then
        notify(src, 'error', 'Armory', 'Armory shop not configured (Config.Armory.ShopId).')
        return
    end

    -- Client will call exports.ox_inventory:openInventory('shop', ...)
    TriggerClientEvent('zf-policejob:client:openArmoryShop', src, shopId)

    if Config.DiscordLogs and Config.DiscordLogs.LogArmory ~= false then
        discordLog('Armory Opened', ('**%s** (%d) opened armory shop: `%s`'):format(GetPlayerName(src) or 'Unknown', src, shopId))
    end
end)

-- ========= Evidence (MULTIPLE STASHES) =========
-- OPEN ON CLIENT (reliable)
RegisterNetEvent('zf-policejob:server:openEvidence', function(stashKey)
    local src = source
    if not isPolice(src) then return end

    if not exports.ox_inventory then
        notify(src, 'error', 'Evidence', 'ox_inventory is required to open evidence stashes.')
        return
    end

    local stashCfg = findEvidenceConfig(stashKey)
    if not stashCfg then
        notify(src, 'error', 'Evidence', 'Invalid evidence stash.')
        return
    end

    local stashId = (Config.EvidenceStashPrefix or 'zf_evidence_') .. tostring(stashCfg.id)

    -- ensure stash exists (safe)
    pcall(function()
        exports.ox_inventory:RegisterStash(
            stashId,
            stashCfg.label or ('Evidence (%s)'):format(stashCfg.id),
            stashCfg.slots or 120,
            stashCfg.maxWeight or 250000,
            false,
            { [Config.PoliceJobName] = 0 }
        )
    end)

    -- Client will call exports.ox_inventory:openInventory('stash', ...)
    TriggerClientEvent('zf-policejob:client:openEvidenceStash', src, stashId)

    if Config.DiscordLogs and Config.DiscordLogs.LogEvidence ~= false then
        discordLog('Evidence Opened', ('**%s** (%d) opened evidence stash: `%s`'):format(GetPlayerName(src) or 'Unknown', src, stashId))
    end
end)

-- ========= Boss =========

RegisterNetEvent('zf-policejob:server:announcement', function(msg)
    local src = source
    if not isBoss(src) then
        notify(src, 'error', 'Boss', 'Not authorized.')
        return
    end

    msg = tostring(msg or '')
    if msg == '' then return end

    for _, id in ipairs(GetPlayers()) do
        local pid = tonumber(id)
        if pid and isPolice(pid) then
            TriggerClientEvent('ox_lib:notify', pid, {
                type = 'inform',
                title = 'Police Announcement',
                description = msg
            })
        end
    end

    if Config.DiscordLogs and Config.DiscordLogs.LogCuffEscort ~= false then
        discordLog('Police Announcement', ('**%s** (%d):\n%s'):format(GetPlayerName(src) or 'Unknown', src, msg))
    end
end)

-- ========= Player Actions =========

RegisterNetEvent('zf-policejob:server:playerAction', function(action, target)
    local src = source
    target = tonumber(target)

    if not target then return end
    if not isPolice(src) then return end
    if GetPlayerPed(target) == 0 then return end

    if not distOk(src, target, 3.0) then
        notify(src, 'error', 'Police', 'Too far away.')
        return
    end

    if action == 'cuff' then
        cuffed[target] = not cuffed[target]
        TriggerClientEvent('zf-policejob:client:setCuffed', target, cuffed[target])

        if Config.DiscordLogs and Config.DiscordLogs.LogCuffEscort ~= false then
            discordLog('Cuff Toggle', ('**%s** (%d) %s **%s** (%d)'):format(
                GetPlayerName(src) or 'Unknown', src,
                cuffed[target] and 'cuffed' or 'uncuffed',
                GetPlayerName(target) or 'Unknown', target
            ))
        end
        return
    end

    if action == 'escort' then
        if not cuffed[target] then
            notify(src, 'error', 'Escort', 'Target must be cuffed.')
            return
        end

        if escorted[target] == src then
            escorted[target] = nil
            TriggerClientEvent('zf-policejob:client:setEscorted', target, false)

            if Config.DiscordLogs and Config.DiscordLogs.LogCuffEscort ~= false then
                discordLog('Escort', ('**%s** (%d) stopped escorting **%s** (%d)'):format(
                    GetPlayerName(src) or 'Unknown', src, GetPlayerName(target) or 'Unknown', target
                ))
            end
        else
            escorted[target] = src
            TriggerClientEvent('zf-policejob:client:setEscorted', target, true, src)

            if Config.DiscordLogs and Config.DiscordLogs.LogCuffEscort ~= false then
                discordLog('Escort', ('**%s** (%d) started escorting **%s** (%d)'):format(
                    GetPlayerName(src) or 'Unknown', src, GetPlayerName(target) or 'Unknown', target
                ))
            end
        end
        return
    end

    if action == 'putinveh' then
        if not cuffed[target] then
            notify(src, 'error', 'Vehicle', 'Target must be cuffed.')
            return
        end
        TriggerClientEvent('zf-policejob:client:putInVehicle', target)
        return
    end

    if action == 'takeoutveh' then
        TriggerClientEvent('zf-policejob:client:takeOutVehicle', target)
        return
    end

    if action == 'search' then
        -- Minimal remove example using ox_inventory
        if not exports.ox_inventory then
            notify(src, 'error', 'Search', 'ox_inventory required for search.')
            return
        end

        local removed = 0
        local function tryRemove(item)
            pcall(function()
                local count = exports.ox_inventory:GetItemCount(target, item)
                if count and count > 0 then
                    exports.ox_inventory:RemoveItem(target, item, count)
                    removed = removed + 1
                end
            end)
        end

        tryRemove('weed')
        tryRemove('coke')
        tryRemove('lockpick')

        notify(src, 'success', 'Search', ('Search complete. Removed categories: %d'):format(removed))
        notify(target, 'warning', 'Searched', 'Police searched you.')

        if Config.DiscordLogs and Config.DiscordLogs.LogCuffEscort ~= false then
            discordLog('Search', ('**%s** (%d) searched **%s** (%d) removed categories: **%d**'):format(
                GetPlayerName(src) or 'Unknown', src, GetPlayerName(target) or 'Unknown', target, removed
            ))
        end
        return
    end
end)

-- ========= Cleanup =========

AddEventHandler('playerDropped', function()
    local src = source
    cuffed[src] = nil
    escorted[src] = nil

    for t, e in pairs(escorted) do
        if e == src then
            escorted[t] = nil
            TriggerClientEvent('zf-policejob:client:setEscorted', t, false)
        end
    end
end)
