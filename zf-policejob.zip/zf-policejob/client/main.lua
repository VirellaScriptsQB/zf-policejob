-- client/main.lua (FIXED + SIMPLIFIED)
-- ✅ NO fines
-- ✅ NO garage
-- ✅ NO player-interaction menu stuff
-- ✅ Armory opens ox_inventory SHOP (opened on CLIENT to avoid server-open issues)
-- ✅ Evidence opens ox_inventory STASH (opened on CLIENT to avoid server-open issues)
-- ✅ 4 evidence stashes (Config.EvidenceStashes)
-- ✅ One PD blip (Config.PDBlip)
-- ✅ zf-textui prompts
-- ✅ Optional vehicle locks toggle (qbx_vehiclekeys)
-- ✅ Still listens for cuff/escort/putinveh/takeoutveh if other scripts/server trigger them

local radialAdded = false
local pdBlip = nil

-- cuff/escort listener state
local isCuffed = false
local isEscorted = false
local escorter = nil
local cuffThreadRunning = false

-- ========= Helpers =========

local function getPlayerData()
    local ok, data = pcall(function()
        return exports.qbx_core:GetPlayerData()
    end)
    return (ok and data) or nil
end

local function isPolice()
    local pd = getPlayerData()
    return pd and pd.job and pd.job.name == Config.PoliceJobName
end

local function isBoss()
    local pd = getPlayerData()
    if not (pd and pd.job and pd.job.name == Config.PoliceJobName) then return false end
    local grade = pd.job.grade and (pd.job.grade.level or pd.job.grade) or 0
    return grade >= (Config.RequiredBossGrade or 0)
end

local function notify(nType, title, message)
    if Config.Notify and Config.Notify.Mode == 'event' then
        TriggerEvent(Config.Notify.EventName, { type = nType or 'info', title = title or 'Police', text = message or '' })
        return
    end
    if lib and lib.notify then
        lib.notify({ type = nType or 'info', title = title or 'Police', description = message or '' })
    end
end

-- ========= zf-textui =========

local function showTextUI(text)
    if Config.TextUI and Config.TextUI.Mode == 'event' then
        TriggerEvent(Config.TextUI.ShowEvent, text)
        return
    end
    if lib and lib.showTextUI then
        lib.showTextUI(text)
    end
end

local function hideTextUI()
    if Config.TextUI and Config.TextUI.Mode == 'event' then
        TriggerEvent(Config.TextUI.HideEvent)
        return
    end
    if lib and lib.hideTextUI then
        lib.hideTextUI()
    end
end

-- ========= Optional vehicle locks =========

local function toggleVehicleLocks()
    if not Config.VehicleKeys then return end
    if Config.VehicleKeys.Mode == 'event' and Config.VehicleKeys.ToggleLocksEvent then
        TriggerEvent(Config.VehicleKeys.ToggleLocksEvent)
        return
    end
    notify('error', 'Vehicle Keys', 'Vehicle keys integration not configured.')
end

-- ========= PD Blip =========

local function removePDBlip()
    if pdBlip and DoesBlipExist(pdBlip) then
        RemoveBlip(pdBlip)
    end
    pdBlip = nil
end

local function ensurePDBlip()
    if not Config.PDBlip or not Config.PDBlip.Enabled then
        removePDBlip()
        return
    end

    if Config.PDBlip.PoliceOnly and not isPolice() then
        removePDBlip()
        return
    end

    if pdBlip and DoesBlipExist(pdBlip) then return end

    local c = Config.PDBlip.coords
    pdBlip = AddBlipForCoord(c.x, c.y, c.z)
    SetBlipSprite(pdBlip, Config.PDBlip.sprite or 60)
    SetBlipColour(pdBlip, Config.PDBlip.color or 29)
    SetBlipScale(pdBlip, Config.PDBlip.scale or 0.85)
    SetBlipDisplay(pdBlip, Config.PDBlip.display or 4)
    SetBlipAsShortRange(pdBlip, Config.PDBlip.shortRange ~= false)

    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(Config.PDBlip.label or 'Police Department')
    EndTextCommandSetBlipName(pdBlip)
end

-- ========= Cuff listener =========

local function startCuffLoop()
    if cuffThreadRunning then return end
    cuffThreadRunning = true

    CreateThread(function()
        while isCuffed do
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 21, true)
            DisableControlAction(0, 22, true)
            DisableControlAction(0, 23, true)
            DisableControlAction(0, 75, true)
            DisableControlAction(0, 44, true)
            DisableControlAction(0, 37, true)
            Wait(0)
        end
        cuffThreadRunning = false
    end)
end

RegisterNetEvent('zf-policejob:client:setCuffed', function(state)
    isCuffed = state and true or false
    if isCuffed then
        startCuffLoop()
    else
        isEscorted = false
        escorter = nil
        DetachEntity(PlayerPedId(), true, false)
    end
end)

RegisterNetEvent('zf-policejob:client:setEscorted', function(state, escorterServerId)
    isEscorted = state and true or false
    escorter = escorterServerId

    if not isEscorted then
        DetachEntity(PlayerPedId(), true, false)
        escorter = nil
        return
    end

    CreateThread(function()
        while isEscorted and escorter do
            local escorterPlayer = GetPlayerFromServerId(escorter)
            if escorterPlayer == -1 then
                isEscorted = false
                DetachEntity(PlayerPedId(), true, false)
                break
            end

            local escortPed = GetPlayerPed(escorterPlayer)
            local myPed = PlayerPedId()
            if DoesEntityExist(escortPed) then
                AttachEntityToEntity(myPed, escortPed, 11816, 0.25, 0.45, 0.0, 0.0, 0.0, 180.0, false, false, false, false, 2, true)
            end
            Wait(500)
        end
    end)
end)

RegisterNetEvent('zf-policejob:client:putInVehicle', function()
    local ped = PlayerPedId()
    local veh = (lib and lib.getClosestVehicle) and lib.getClosestVehicle(GetEntityCoords(ped), 6.0, false) or nil
    if not veh then return end

    for i = 1, 6 do
        if IsVehicleSeatFree(veh, i) then
            TaskWarpPedIntoVehicle(ped, veh, i)
            return
        end
    end
    TaskWarpPedIntoVehicle(ped, veh, 2)
end)

RegisterNetEvent('zf-policejob:client:takeOutVehicle', function()
    local ped = PlayerPedId()
    TaskLeaveVehicle(ped, GetVehiclePedIsIn(ped, false), 16)
end)

-- ========= ox_inventory open helpers (RELIABLE) =========

local function openOxInventory(invType, data)
    if not exports.ox_inventory then
        notify('error', 'Inventory', 'ox_inventory not found.')
        return false
    end

    -- preferred: openInventory(type, dataTable)
    local ok = pcall(function()
        exports.ox_inventory:openInventory(invType, data)
    end)
    if ok then return true end

    -- fallback: openInventory(type, idString)
    ok = pcall(function()
        exports.ox_inventory:openInventory(invType, data and (data.id or data.type) or nil)
    end)
    return ok == true
end

-- server -> client: open stash/shop
RegisterNetEvent('zf-policejob:client:openEvidenceStash', function(stashId)
    if not stashId or stashId == '' then return end
    openOxInventory('stash', { id = stashId })
end)

RegisterNetEvent('zf-policejob:client:openArmoryShop', function(shopId)
    if not shopId or shopId == '' then return end
    openOxInventory('shop', { type = shopId })
end)

-- ========= Evidence (menu + zones) =========

local function openEvidenceStashKey(stashKey)
    if not isPolice() then return end
    if not stashKey or stashKey == '' then return end
    TriggerServerEvent('zf-policejob:server:openEvidence', stashKey)
end

local function openEvidenceMenu()
    if not isPolice() then return end
    if not lib or not lib.registerContext then
        notify('error', 'Menu', 'ox_lib missing (context menus).')
        return
    end

    local options = {}
    for _, stash in ipairs(Config.EvidenceStashes or {}) do
        options[#options + 1] = {
            title = stash.label or ('Evidence (%s)'):format(stash.id or 'unknown'),
            icon = 'box-archive',
            onSelect = function()
                openEvidenceStashKey(stash.id)
            end
        }
    end

    if #options == 0 then
        options[#options + 1] = { title = 'No evidence stashes configured', disabled = true }
    end

    lib.registerContext({
        id = 'zf_police_evidence',
        title = 'Evidence Stashes',
        options = options
    })
    lib.showContext('zf_police_evidence')
end

-- ========= Armory =========

local function openArmoryShop()
    if not isPolice() then return end
    TriggerServerEvent('zf-policejob:server:openArmoryShop')
end

-- ========= Boss (no input dialogs) =========

local function openBossMenu()
    if not isBoss() then
        notify('error', 'Boss', 'Not authorized.')
        return
    end
    if not lib or not lib.registerContext then
        notify('error', 'Menu', 'ox_lib missing (context menus).')
        return
    end

    lib.registerContext({
        id = 'zf_police_boss',
        title = 'Boss Actions',
        options = {
            {
                title = 'Announcement (Fixed)',
                icon = 'bullhorn',
                onSelect = function()
                    TriggerServerEvent('zf-policejob:server:announcement', 'All units: announcement issued.')
                end
            }
        }
    })
    lib.showContext('zf_police_boss')
end

-- ========= Main menu =========

local function openPoliceMenu()
    if not isPolice() then
        notify('error', 'Police', 'You are not police.')
        return
    end
    if not lib or not lib.showContext then
        notify('error', 'Menu', 'ox_lib missing (context menus).')
        return
    end
    lib.showContext('zf_police_main')
end

local function registerMenus()
    if not lib or not lib.registerContext then return end

    lib.registerContext({
        id = 'zf_police_main',
        title = 'Police Menu',
        options = {
            { title = 'Armory', icon = 'basket-shopping', onSelect = openArmoryShop },
            { title = 'Evidence', icon = 'box-archive', onSelect = openEvidenceMenu },
            { title = 'Vehicle Locks', icon = 'key', onSelect = toggleVehicleLocks },
            { title = 'Boss Actions', icon = 'user-tie', onSelect = openBossMenu },
        }
    })
end

-- ========= Radial =========

local function addRadial()
    if radialAdded then return end
    radialAdded = true

    if not lib or not lib.addRadialItem then
        print('[zf-policejob] ox_lib radial not available.')
        return
    end

    lib.addRadialItem({
        id = Config.Radial.id,
        label = Config.Radial.label,
        icon = Config.Radial.icon,
        onSelect = openPoliceMenu
    })
end

local function removeRadial()
    if not radialAdded then return end
    radialAdded = false
    pcall(function()
        if lib and lib.removeRadialItem then
            lib.removeRadialItem(Config.Radial.id)
        end
    end)
end

local function refreshRadial()
    if isPolice() then addRadial() else removeRadial() end
end

-- ========= Zones =========

local function addZone(coord, label, onUse)
    if not lib or not lib.zones or not lib.zones.sphere then
        print('[zf-policejob] ox_lib zones not available.')
        return
    end

    local showing = false

    lib.zones.sphere({
        coords = coord,
        radius = 1.6,
        debug = false,
        inside = function()
            if not isPolice() then
                if showing then
                    hideTextUI()
                    showing = false
                end
                return
            end

            if not showing then
                showTextUI(('[E] %s'):format(label))
                showing = true
            end

            if IsControlJustPressed(0, 38) then
                onUse()
            end
        end,
        onExit = function()
            if showing then
                hideTextUI()
                showing = false
            end
        end
    })
end

-- ========= Start =========

CreateThread(function()
    registerMenus()

    -- Duty
    for _, c in ipairs((Config.Locations and Config.Locations.Duty) or {}) do
        addZone(c, 'Duty Locker', function()
            TriggerServerEvent('zf-policejob:server:toggleDuty')
        end)
    end

    -- Armory
    for _, c in ipairs((Config.Locations and Config.Locations.Armory) or {}) do
        addZone(c, 'Armory', openArmoryShop)
    end

    -- Boss
    for _, c in ipairs((Config.Locations and Config.Locations.Boss) or {}) do
        addZone(c, 'Boss Actions', openBossMenu)
    end

    -- Evidence zones (from Config.EvidenceStashes)
    for _, stash in ipairs(Config.EvidenceStashes or {}) do
        if stash.coords then
            addZone(stash.coords, stash.label or 'Evidence', function()
                openEvidenceStashKey(stash.id)
            end)
        end
    end

    Wait(800)
    refreshRadial()
    ensurePDBlip()

    while true do
        Wait(3000)
        refreshRadial()
        ensurePDBlip()
    end
end)
